from setuptools import setup, find_packages
setup(name='photon',version='1.3.0.post1',py_modules=['photon','photon_launcher'],packages=find_packages(),package_data={'core':['user-agents.txt']},install_requires=['requests','urllib3','tld'],entry_points={'console_scripts':['photon=photon_launcher:main']},license='GPL-3.0')
