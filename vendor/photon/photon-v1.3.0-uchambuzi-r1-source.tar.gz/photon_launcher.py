import runpy
def main():
    runpy.run_module('photon', run_name='__main__')
