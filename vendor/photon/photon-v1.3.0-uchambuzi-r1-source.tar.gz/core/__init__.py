"""The Photon core."""
